import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  ArrowRight, 
  Users, 
  TrendingUp, 
  DollarSign, 
  Target, 
  CheckCircle, 
  Star,
  Handshake,
  BarChart3,
  Gift,
  Zap,
  Shield,
  Clock,
  Globe
} from 'lucide-react';

const AffiliateProgram = () => {
  const features = [
    {
      icon: <DollarSign className="h-8 w-8 text-primary" />,
      title: "High Commissions",
      description: "Earn up to 70% commission on every sale you generate",
      highlight: "Up to 70%"
    },
    {
      icon: <Users className="h-8 w-8 text-primary" />,
      title: "Two-Level System",
      description: "Earn 10% additional commission from your referrals' sales",
      highlight: "10% Bonus"
    },
    {
      icon: <Zap className="h-8 w-8 text-primary" />,
      title: "Real-Time Tracking",
      description: "Monitor your clicks, conversions, and earnings instantly",
      highlight: "Live Analytics"
    },
    {
      icon: <Shield className="h-8 w-8 text-primary" />,
      title: "Secure Payments",
      description: "Automated payouts with multiple payment options",
      highlight: "Auto Payouts"
    },
    {
      icon: <Globe className="h-8 w-8 text-primary" />,
      title: "Global Reach",
      description: "Promote products to customers worldwide",
      highlight: "Worldwide"
    },
    {
      icon: <Gift className="h-8 w-8 text-primary" />,
      title: "Bonus Rewards",
      description: "Extra bonuses for top performers and milestones",
      highlight: "Bonuses"
    }
  ];

  const steps = [
    {
      number: "01",
      title: "Sign Up",
      description: "Create your free affiliate account in under 2 minutes",
      icon: <Users className="h-6 w-6" />
    },
    {
      number: "02",
      title: "Choose Products",
      description: "Browse our catalog and select products to promote",
      icon: <Target className="h-6 w-6" />
    },
    {
      number: "03",
      title: "Get Your Links",
      description: "Generate unique affiliate links for tracking",
      icon: <Handshake className="h-6 w-6" />
    },
    {
      number: "04",
      title: "Start Promoting",
      description: "Share your links and start earning commissions",
      icon: <TrendingUp className="h-6 w-6" />
    }
  ];

  const commissionTiers = [
    {
      level: "Level 1 - Direct Sales",
      percentage: "50%",
      description: "Earn 50% commission on every direct sale you generate",
      color: "bg-blue-500",
      features: [
        "Instant commission tracking",
        "Real-time analytics",
        "Multiple payment methods",
        "24/7 support"
      ]
    },
    {
      level: "Level 2 - Network Sales",
      percentage: "10%",
      description: "Earn 10% commission from sales made by your referrals",
      color: "bg-green-500",
      features: [
        "Passive income stream",
        "Network growth tracking",
        "Referral management tools",
        "Team performance insights"
      ]
    }
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Top Affiliate",
      earnings: "₦450,000",
      period: "Last 3 months",
      content: "Hisnak's two-level commission system helped me build a sustainable income. The platform is user-friendly and the support is excellent.",
      rating: 5,
      avatar: "SJ"
    },
    {
      name: "Michael Chen",
      role: "Digital Marketer",
      earnings: "₦320,000",
      period: "Last 3 months",
      content: "The real-time analytics and high commission rates make this the best affiliate program I've joined. Highly recommended!",
      rating: 5,
      avatar: "MC"
    },
    {
      name: "Aisha Okafor",
      role: "Content Creator",
      earnings: "₦280,000",
      period: "Last 3 months",
      content: "Building my affiliate network has never been easier. The automated payouts and transparent tracking are game-changers.",
      rating: 5,
      avatar: "AO"
    }
  ];

  const faqs = [
    {
      question: "How much can I earn as an affiliate?",
      answer: "Your earnings depend on your promotional efforts and network size. Top affiliates earn ₦100,000+ monthly through direct sales and referral bonuses."
    },
    {
      question: "When do I get paid?",
      answer: "Commissions are paid automatically when you reach the minimum threshold of ₦2,000. Payments are processed within 1-3 business days."
    },
    {
      question: "How does the two-level system work?",
      answer: "You earn 50% commission on direct sales and 10% commission on sales made by affiliates you refer to the platform."
    },
    {
      question: "What marketing materials do you provide?",
      answer: "We provide banners, product images, email templates, and AI-generated content to help you promote effectively."
    },
    {
      question: "Is there a cost to join?",
      answer: "No, joining our affiliate program is completely free. There are no hidden fees or monthly charges."
    },
    {
      question: "Can I promote on social media?",
      answer: "Yes! You can promote on all major social media platforms, blogs, websites, and through email marketing."
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 via-white to-primary/5 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <Badge className="mb-4" variant="outline">
              Two-Level Commission System
            </Badge>
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              Join Our
              <span className="text-primary"> Affiliate Program</span>
            </h1>
            <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Earn up to 70% commission on sales plus 10% from your referrals. 
              Build your network and create multiple income streams with our 
              innovative two-level affiliate system.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/register?type=affiliate">
                <Button size="lg" className="w-full sm:w-auto">
                  Join Now - It's Free
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Button variant="outline" size="lg" className="w-full sm:w-auto">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose Our Affiliate Program?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We offer the most competitive commission structure and advanced 
              tools to help you succeed.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow text-center">
                <CardHeader>
                  <div className="mb-4 flex justify-center">{feature.icon}</div>
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                  <Badge variant="secondary" className="mx-auto">
                    {feature.highlight}
                  </Badge>
                </CardHeader>
                <CardContent>
                  <CardDescription className="text-gray-600">
                    {feature.description}
                  </CardDescription>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Commission Structure */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Two-Level Commission Structure
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Our innovative system rewards both direct sales and network building.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {commissionTiers.map((tier, index) => (
              <Card key={index} className="border-2 border-primary/20 shadow-lg">
                <CardHeader className="text-center">
                  <div className={`w-16 h-16 ${tier.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                    <span className="text-white text-2xl font-bold">{tier.percentage}</span>
                  </div>
                  <CardTitle className="text-2xl">{tier.level}</CardTitle>
                  <CardDescription className="text-lg">{tier.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {tier.features.map((feature, featureIndex) => (
                      <li key={featureIndex} className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Commission Example */}
          <Card className="mt-12 bg-primary/5 border-primary/20">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Commission Example</CardTitle>
              <CardDescription>See how much you can earn with our two-level system</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center">
                <div className="p-4 bg-white rounded-lg">
                  <h4 className="font-semibold text-lg mb-2">Your Direct Sale</h4>
                  <div className="text-3xl font-bold text-primary">₦7,500</div>
                  <p className="text-sm text-gray-600">50% of ₦15,000 product</p>
                </div>
                <div className="p-4 bg-white rounded-lg">
                  <h4 className="font-semibold text-lg mb-2">Referral Sale</h4>
                  <div className="text-3xl font-bold text-green-600">₦1,500</div>
                  <p className="text-sm text-gray-600">10% of ₦15,000 product</p>
                </div>
                <div className="p-4 bg-white rounded-lg border-2 border-primary">
                  <h4 className="font-semibold text-lg mb-2">Total Earned</h4>
                  <div className="text-3xl font-bold text-primary">₦9,000</div>
                  <p className="text-sm text-gray-600">From one product cycle</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Get started in just 4 simple steps and begin earning immediately.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="relative mb-6">
                  <div className="w-16 h-16 bg-primary rounded-full flex items-center justify-center mx-auto mb-4">
                    {step.icon}
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-primary/20 rounded-full flex items-center justify-center">
                    <span className="text-primary font-bold text-sm">{step.number}</span>
                  </div>
                </div>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Success Stories
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              See how our affiliates are building successful businesses with our platform.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-0 shadow-lg">
                <CardContent className="pt-6">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-gray-600 mb-6">"{testimonial.content}"</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mr-3">
                        <span className="text-primary font-medium">{testimonial.avatar}</span>
                      </div>
                      <div>
                        <div className="font-semibold">{testimonial.name}</div>
                        <div className="text-sm text-gray-500">{testimonial.role}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-primary">{testimonial.earnings}</div>
                      <div className="text-xs text-gray-500">{testimonial.period}</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Frequently Asked Questions
            </h2>
            <p className="text-xl text-gray-600">
              Everything you need to know about our affiliate program.
            </p>
          </div>
          
          <div className="space-y-6">
            {faqs.map((faq, index) => (
              <Card key={index}>
                <CardContent className="pt-6">
                  <h3 className="text-lg font-semibold mb-2">{faq.question}</h3>
                  <p className="text-gray-600">{faq.answer}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Start Earning?
          </h2>
          <p className="text-xl text-primary-foreground/80 mb-8 max-w-2xl mx-auto">
            Join thousands of successful affiliates who are building their income 
            with our innovative two-level commission system.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/register?type=affiliate">
              <Button size="lg" variant="secondary" className="w-full sm:w-auto">
                Join the Program Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/contact">
              <Button size="lg" variant="outline" className="w-full sm:w-auto border-white text-white hover:bg-white hover:text-primary">
                Contact Us
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AffiliateProgram;

