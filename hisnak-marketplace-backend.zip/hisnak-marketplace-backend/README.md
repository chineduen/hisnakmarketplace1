# Hisnak Marketplace Backend

A comprehensive Flask-based backend API for the Hisnak Marketplace - an AI-powered affiliate networking platform with multi-level commission tracking, payment gateway integration, and automated payout systems.

## 🚀 Features

### Core Functionality
- **Multi-level Commission System**: 2-level commission structure (50% direct, 10% indirect)
- **Payment Gateway Integration**: Paystack, Flutterwave, Google Pay, PayPal, Stripe, and Bank Transfer
- **Automated Split Payments**: Real-time commission distribution at point of purchase
- **KYC Verification System**: Document upload and admin approval workflow
- **Bank Account Management**: Nigerian bank integration with BVN/NIN validation
- **Withdrawal System**: Minimum ₦2,000 withdrawal with automated processing
- **Role-Based Access Control**: Admin, Vendor, and Affiliate user roles

### Advanced Features
- **Referral Tracking**: Unique referral links and referral tree management
- **Product Management**: Digital and physical product support with approval workflow
- **Review System**: Product reviews and ratings
- **Blog CMS**: Content management system for blog posts
- **Analytics Dashboard**: Comprehensive reporting for all user roles
- **Real-time Notifications**: System notifications and alerts

## 📋 API Endpoints

### Authentication (`/api/auth/`)
- `POST /register` - User registration with role selection
- `POST /login` - User authentication
- `POST /logout` - User logout
- `GET /profile` - Get current user profile
- `PUT /profile` - Update user profile

### Affiliate Management (`/api/affiliate/`)
- `GET /dashboard` - Affiliate dashboard statistics
- `GET /links` - Get affiliate links
- `POST /links` - Create new affiliate link
- `PUT /links/<id>` - Update affiliate link
- `DELETE /links/<id>` - Delete affiliate link
- `GET /commissions` - Commission history
- `GET /referrals` - Referral information and tree
- `GET /performance` - Performance analytics

### Payment System (`/api/payment/`)
- `GET /banks` - Get Nigerian banks list
- `POST /initialize` - Initialize payment with gateway
- `POST /paystack/webhook` - Paystack webhook handler
- `POST /flutterwave/webhook` - Flutterwave webhook handler
- `GET /verify/<ref>` - Verify payment status
- `GET /bank-accounts` - Get user bank accounts
- `POST /bank-accounts` - Add bank account
- `GET /withdrawals` - Withdrawal history
- `POST /withdrawals` - Request withdrawal

### Product Management (`/api/products/`)
- `GET /` - Get products with filtering
- `GET /<id>` - Get single product
- `POST /` - Create product (vendors only)
- `PUT /<id>` - Update product
- `DELETE /<id>` - Delete product
- `GET /categories` - Get product categories
- `GET /<id>/reviews` - Get product reviews
- `POST /<id>/reviews` - Create review

### Admin Panel (`/api/admin/`)
- `GET /dashboard` - Admin dashboard statistics
- `GET /users` - Manage users
- `GET /products` - Manage products
- `POST /products/<id>/approve` - Approve product
- `POST /products/<id>/reject` - Reject product
- `GET /kyc` - KYC document management
- `POST /kyc/<id>/approve` - Approve KYC
- `GET /withdrawals` - Withdrawal management
- `POST /withdrawals/<id>/approve` - Approve withdrawal
- `GET /analytics/overview` - Platform analytics

### Vendor Dashboard (`/api/vendor/`)
- `GET /dashboard` - Vendor statistics
- `GET /products` - Vendor's products
- `GET /orders` - Vendor's orders
- `GET /affiliates` - Vendor's affiliates
- `GET /analytics/overview` - Vendor analytics
- `GET /reviews` - Product reviews

### User Features (`/api/user/`)
- `GET /profile` - User profile
- `PUT /profile` - Update profile
- `GET /blog` - Public blog posts
- `GET /blog/<slug>` - Single blog post
- `GET /stats` - Platform statistics

## 🛠 Installation & Setup

### Prerequisites
- Python 3.11+
- pip package manager
- Virtual environment (recommended)

### Installation Steps

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd hisnak-marketplace-backend
   ```

2. **Create and activate virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Set up environment variables**
   ```bash
   cp .env.example .env
   # Edit .env file with your configuration
   ```

5. **Initialize the database**
   ```bash
   python init_db.py
   ```

6. **Run the application**
   ```bash
   cd src
   python main.py
   ```

The API will be available at `http://localhost:5000`

## ⚙️ Configuration

### Environment Variables

Create a `.env` file in the root directory with the following variables:

```env
# Flask Configuration
FLASK_ENV=development
FLASK_DEBUG=True
SECRET_KEY=your-secret-key-change-in-production

# Database Configuration
DATABASE_URL=sqlite:///hisnak_marketplace.db

# JWT Configuration
JWT_SECRET_KEY=your-jwt-secret-key-change-in-production
JWT_ACCESS_TOKEN_EXPIRES=3600

# Payment Gateway Configuration
PAYSTACK_SECRET_KEY=sk_test_your_paystack_secret_key
PAYSTACK_PUBLIC_KEY=pk_test_your_paystack_public_key

FLUTTERWAVE_SECRET_KEY=FLWSECK_TEST-your_flutterwave_secret_key
FLUTTERWAVE_PUBLIC_KEY=FLWPUBK_TEST-your_flutterwave_public_key
FLUTTERWAVE_WEBHOOK_SECRET=your_flutterwave_webhook_secret

# CORS Configuration
CORS_ORIGINS=http://localhost:3000,http://localhost:5173
```

### Payment Gateway Setup

#### Paystack Integration
1. Sign up at [Paystack](https://paystack.com)
2. Get your API keys from the dashboard
3. Set up webhook URL: `https://yourdomain.com/api/payment/paystack/webhook`

#### Flutterwave Integration
1. Sign up at [Flutterwave](https://flutterwave.com)
2. Get your API keys from the dashboard
3. Set up webhook URL: `https://yourdomain.com/api/payment/flutterwave/webhook`

## 💳 Commission System

### How It Works

1. **Affiliate Registration**: Users register as affiliates and get unique referral codes
2. **Referral Tracking**: When someone registers using a referral code, they become a "downline"
3. **Product Promotion**: Affiliates create unique links for products they want to promote
4. **Commission Distribution**: When a sale occurs through an affiliate link:
   - **50%** goes to the direct affiliate (Level 1)
   - **10%** goes to the affiliate's recruiter (Level 2)
   - **40%** goes to Hisnak Marketplace

### Commission Calculation Example

Product Price: ₦10,000
Commission Rate: 60%
Total Commission: ₦6,000

- Direct Affiliate (Level 1): ₦3,000 (50% of commission)
- Recruiter (Level 2): ₦600 (10% of commission)
- Platform: ₦4,000 (40% of total price)

## 🏦 Bank Account & Withdrawal System

### Supported Banks
- All major Nigerian banks (Access Bank, GTBank, First Bank, UBA, etc.)
- 10-digit account number validation
- BVN and NIN verification required

### Withdrawal Process
1. Minimum withdrawal: ₦2,000
2. User requests withdrawal through dashboard
3. Admin reviews and approves
4. Automatic processing to user's bank account
5. Processing time: 1-3 business days

## 🔐 Security Features

- JWT-based authentication
- Password hashing with Werkzeug
- SQL injection prevention with SQLAlchemy ORM
- CORS configuration for cross-origin requests
- Input validation and sanitization
- Rate limiting (to be implemented)

## 📊 Database Schema

### Key Models

#### User
- Authentication and profile information
- Role-based access (Admin, Vendor, Affiliate)
- Referral tracking and commission balance

#### Product
- Digital and physical product support
- Vendor association and approval workflow
- Commission percentage configuration

#### Transaction
- Payment tracking and status management
- Affiliate link association for commission calculation
- Multiple payment gateway support

#### Commission
- Multi-level commission tracking
- Direct and indirect commission types
- Automated calculation and distribution

#### BankAccount
- Nigerian bank account management
- BVN/NIN verification
- Withdrawal destination configuration

## 🚀 Deployment

### Production Setup

1. **Use a production WSGI server**
   ```bash
   pip install gunicorn
   gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
   ```

2. **Set up a reverse proxy** (Nginx recommended)

3. **Use a production database** (PostgreSQL recommended)

4. **Set up SSL/TLS** for HTTPS

5. **Configure environment variables** for production

### Docker Deployment (Optional)

```dockerfile
FROM python:3.11-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .
EXPOSE 5000

CMD ["gunicorn", "-w", "4", "-b", "0.0.0.0:5000", "src.main:app"]
```

## 🧪 Testing

### API Testing

Use tools like Postman or curl to test the API endpoints:

```bash
# Health check
curl http://localhost:5000/api/health

# Register user
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username":"testuser","email":"test@example.com","password":"password123","role":"affiliate"}'

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"password123"}'
```

## 📈 Monitoring & Analytics

### Built-in Analytics
- User registration and activity tracking
- Product performance metrics
- Commission distribution reports
- Payment gateway transaction logs
- Affiliate performance analytics

### Logging
- Comprehensive logging with Python's logging module
- Error tracking and debugging information
- Payment gateway webhook logs

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is proprietary software for Hisnak Marketplace.

## 🆘 Support

For technical support or questions:
- Email: support@hisnak.com
- Documentation: [API Docs](http://localhost:5000/api/docs)

## 🔄 Version History

### v1.0.0 (Current)
- Initial release with core functionality
- Multi-level commission system
- Payment gateway integration
- KYC verification system
- Bank account management
- Withdrawal system
- Admin dashboard
- Vendor and affiliate dashboards

---

**Note**: This is a development version. Please ensure proper security measures and testing before deploying to production.

