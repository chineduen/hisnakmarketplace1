from flask import Blueprint, request, jsonify
from src.models.user import db, Product, User, ProductStatus, ProductType, ProductReview
from src.routes.auth import token_required, role_required
from datetime import datetime, timezone
from decimal import Decimal
import uuid
import re

product_bp = Blueprint('product', __name__)

def generate_slug(title):
    """Generate URL-friendly slug from title"""
    slug = re.sub(r'[^\w\s-]', '', title.lower())
    slug = re.sub(r'[-\s]+', '-', slug)
    return slug.strip('-')

@product_bp.route('/', methods=['GET'])
def get_products():
    """Get products with filtering and pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        category = request.args.get('category')
        product_type = request.args.get('type')
        search = request.args.get('search')
        featured = request.args.get('featured', type=bool)
        min_price = request.args.get('min_price', type=float)
        max_price = request.args.get('max_price', type=float)
        
        # Base query - only approved and active products
        query = Product.query.filter_by(
            status=ProductStatus.APPROVED,
            is_active=True
        )
        
        # Apply filters
        if category:
            query = query.filter(Product.category.ilike(f'%{category}%'))
        
        if product_type:
            try:
                product_type_enum = ProductType(product_type)
                query = query.filter_by(product_type=product_type_enum)
            except ValueError:
                pass
        
        if search:
            query = query.filter(
                db.or_(
                    Product.name.ilike(f'%{search}%'),
                    Product.description.ilike(f'%{search}%'),
                    Product.short_description.ilike(f'%{search}%')
                )
            )
        
        if featured is not None:
            query = query.filter_by(is_featured=featured)
        
        if min_price is not None:
            query = query.filter(Product.price >= min_price)
        
        if max_price is not None:
            query = query.filter(Product.price <= max_price)
        
        # Order by featured first, then by creation date
        query = query.order_by(Product.is_featured.desc(), Product.created_at.desc())
        
        # Paginate
        products = query.paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'products': [product.to_dict() for product in products.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': products.total,
                'pages': products.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@product_bp.route('/<product_id>', methods=['GET'])
def get_product(product_id):
    """Get single product details"""
    try:
        product = Product.query.filter_by(
            id=product_id,
            status=ProductStatus.APPROVED,
            is_active=True
        ).first()
        
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # Increment view count
        product.views_count += 1
        db.session.commit()
        
        # Get product reviews
        reviews = ProductReview.query.filter_by(
            product_id=product.id,
            is_approved=True
        ).order_by(ProductReview.created_at.desc()).limit(10).all()
        
        # Get vendor information
        vendor = User.query.get(product.vendor_id)
        
        product_data = product.to_dict()
        product_data['reviews'] = [review.to_dict() for review in reviews]
        product_data['vendor'] = {
            'id': vendor.id,
            'username': vendor.username,
            'first_name': vendor.first_name,
            'last_name': vendor.last_name
        } if vendor else None
        
        return jsonify({'product': product_data}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@product_bp.route('/', methods=['POST'])
@token_required
@role_required(['vendor'])
def create_product(current_user):
    """Create a new product"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'description', 'price', 'product_type', 'category']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Validate product type
        try:
            product_type = ProductType(data['product_type'])
        except ValueError:
            return jsonify({'error': 'Invalid product type. Must be digital or physical'}), 400
        
        # Validate price
        try:
            price = Decimal(str(data['price']))
            if price <= 0:
                return jsonify({'error': 'Price must be greater than 0'}), 400
        except (ValueError, TypeError):
            return jsonify({'error': 'Invalid price format'}), 400
        
        # Validate commission percentage (50-70%)
        commission_percentage = Decimal(str(data.get('commission_percentage', 50)))
        if commission_percentage < 50 or commission_percentage > 70:
            return jsonify({'error': 'Commission percentage must be between 50% and 70%'}), 400
        
        # Create product
        product = Product(
            vendor_id=current_user.id,
            name=data['name'],
            description=data['description'],
            short_description=data.get('short_description'),
            price=price,
            currency=data.get('currency', 'NGN'),
            product_type=product_type,
            category=data['category'],
            commission_percentage=commission_percentage,
            download_url=data.get('download_url') if product_type == ProductType.DIGITAL else None,
            file_size=data.get('file_size') if product_type == ProductType.DIGITAL else None,
            weight=data.get('weight') if product_type == ProductType.PHYSICAL else None,
            dimensions=data.get('dimensions') if product_type == ProductType.PHYSICAL else None,
            shipping_required=data.get('shipping_required', False) if product_type == ProductType.PHYSICAL else False,
            meta_title=data.get('meta_title'),
            meta_description=data.get('meta_description')
        )
        
        # Generate slug
        product.slug = generate_slug(product.name)
        
        # Handle tags
        if data.get('tags'):
            product.set_tags_list(data['tags'])
        
        db.session.add(product)
        db.session.commit()
        
        return jsonify({
            'message': 'Product created successfully',
            'product': product.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@product_bp.route('/<product_id>', methods=['PUT'])
@token_required
@role_required(['vendor'])
def update_product(current_user, product_id):
    """Update product"""
    try:
        product = Product.query.filter_by(
            id=product_id,
            vendor_id=current_user.id
        ).first()
        
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # Check if product can be edited (not approved products need admin re-approval)
        if product.status == ProductStatus.APPROVED:
            product.status = ProductStatus.PENDING  # Require re-approval after edit
        
        data = request.get_json()
        
        # Update allowed fields
        allowed_fields = [
            'name', 'description', 'short_description', 'price', 'category',
            'commission_percentage', 'download_url', 'file_size', 'weight',
            'dimensions', 'shipping_required', 'meta_title', 'meta_description',
            'is_active'
        ]
        
        for field in allowed_fields:
            if field in data:
                if field == 'price':
                    try:
                        price = Decimal(str(data[field]))
                        if price <= 0:
                            return jsonify({'error': 'Price must be greater than 0'}), 400
                        product.price = price
                    except (ValueError, TypeError):
                        return jsonify({'error': 'Invalid price format'}), 400
                elif field == 'commission_percentage':
                    commission_percentage = Decimal(str(data[field]))
                    if commission_percentage < 50 or commission_percentage > 70:
                        return jsonify({'error': 'Commission percentage must be between 50% and 70%'}), 400
                    product.commission_percentage = commission_percentage
                else:
                    setattr(product, field, data[field])
        
        # Update slug if name changed
        if 'name' in data:
            product.slug = generate_slug(data['name'])
        
        # Handle tags
        if 'tags' in data:
            product.set_tags_list(data['tags'])
        
        product.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'message': 'Product updated successfully',
            'product': product.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@product_bp.route('/<product_id>', methods=['DELETE'])
@token_required
@role_required(['vendor'])
def delete_product(current_user, product_id):
    """Delete product (soft delete)"""
    try:
        product = Product.query.filter_by(
            id=product_id,
            vendor_id=current_user.id
        ).first()
        
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        product.is_active = False
        product.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({'message': 'Product deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@product_bp.route('/categories', methods=['GET'])
def get_categories():
    """Get product categories"""
    try:
        categories = db.session.query(Product.category)\
            .filter(Product.status == ProductStatus.APPROVED)\
            .distinct().all()
        
        category_list = [category[0] for category in categories if category[0]]
        
        return jsonify({'categories': category_list}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@product_bp.route('/<product_id>/reviews', methods=['GET'])
def get_product_reviews(product_id):
    """Get product reviews"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        
        reviews = ProductReview.query.filter_by(
            product_id=product_id,
            is_approved=True
        ).order_by(ProductReview.created_at.desc())\
        .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'reviews': [review.to_dict() for review in reviews.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': reviews.total,
                'pages': reviews.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@product_bp.route('/<product_id>/reviews', methods=['POST'])
@token_required
def create_product_review(current_user, product_id):
    """Create a product review"""
    try:
        # Check if product exists
        product = Product.query.filter_by(
            id=product_id,
            status=ProductStatus.APPROVED,
            is_active=True
        ).first()
        
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # Check if user already reviewed this product
        existing_review = ProductReview.query.filter_by(
            product_id=product_id,
            user_id=current_user.id
        ).first()
        
        if existing_review:
            return jsonify({'error': 'You have already reviewed this product'}), 400
        
        data = request.get_json()
        
        # Validate required fields
        if not data.get('rating'):
            return jsonify({'error': 'Rating is required'}), 400
        
        rating = int(data['rating'])
        if rating < 1 or rating > 5:
            return jsonify({'error': 'Rating must be between 1 and 5'}), 400
        
        # Create review
        review = ProductReview(
            product_id=product_id,
            user_id=current_user.id,
            rating=rating,
            title=data.get('title'),
            comment=data.get('comment')
        )
        
        db.session.add(review)
        db.session.commit()
        
        return jsonify({
            'message': 'Review submitted successfully',
            'review': review.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@product_bp.route('/featured', methods=['GET'])
def get_featured_products():
    """Get featured products"""
    try:
        limit = request.args.get('limit', 10, type=int)
        
        products = Product.query.filter_by(
            status=ProductStatus.APPROVED,
            is_active=True,
            is_featured=True
        ).order_by(Product.created_at.desc()).limit(limit).all()
        
        return jsonify({
            'products': [product.to_dict() for product in products]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@product_bp.route('/search', methods=['GET'])
def search_products():
    """Advanced product search"""
    try:
        query_text = request.args.get('q', '')
        category = request.args.get('category')
        min_price = request.args.get('min_price', type=float)
        max_price = request.args.get('max_price', type=float)
        product_type = request.args.get('type')
        sort_by = request.args.get('sort_by', 'relevance')  # relevance, price_asc, price_desc, newest
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Base query
        query = Product.query.filter_by(
            status=ProductStatus.APPROVED,
            is_active=True
        )
        
        # Text search
        if query_text:
            query = query.filter(
                db.or_(
                    Product.name.ilike(f'%{query_text}%'),
                    Product.description.ilike(f'%{query_text}%'),
                    Product.short_description.ilike(f'%{query_text}%'),
                    Product.category.ilike(f'%{query_text}%')
                )
            )
        
        # Apply filters
        if category:
            query = query.filter(Product.category.ilike(f'%{category}%'))
        
        if product_type:
            try:
                product_type_enum = ProductType(product_type)
                query = query.filter_by(product_type=product_type_enum)
            except ValueError:
                pass
        
        if min_price is not None:
            query = query.filter(Product.price >= min_price)
        
        if max_price is not None:
            query = query.filter(Product.price <= max_price)
        
        # Apply sorting
        if sort_by == 'price_asc':
            query = query.order_by(Product.price.asc())
        elif sort_by == 'price_desc':
            query = query.order_by(Product.price.desc())
        elif sort_by == 'newest':
            query = query.order_by(Product.created_at.desc())
        else:  # relevance or default
            query = query.order_by(Product.is_featured.desc(), Product.views_count.desc())
        
        # Paginate
        products = query.paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'products': [product.to_dict() for product in products.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': products.total,
                'pages': products.pages
            },
            'search_params': {
                'query': query_text,
                'category': category,
                'min_price': min_price,
                'max_price': max_price,
                'type': product_type,
                'sort_by': sort_by
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

