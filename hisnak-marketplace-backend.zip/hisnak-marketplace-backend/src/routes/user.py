from flask import Blueprint, request, jsonify
from src.models.user import db, User, BlogPost
from src.routes.auth import token_required
from datetime import datetime, timezone

user_bp = Blueprint('user', __name__)

@user_bp.route('/profile', methods=['GET'])
@token_required
def get_user_profile(current_user):
    """Get current user profile"""
    try:
        return jsonify({
            'user': current_user.to_dict()
        }), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@user_bp.route('/profile', methods=['PUT'])
@token_required
def update_user_profile(current_user):
    """Update current user profile"""
    try:
        data = request.get_json()
        
        # Update allowed fields
        allowed_fields = ['first_name', 'last_name', 'phone']
        for field in allowed_fields:
            if field in data:
                setattr(current_user, field, data[field])
        
        current_user.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'message': 'Profile updated successfully',
            'user': current_user.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@user_bp.route('/notifications', methods=['GET'])
@token_required
def get_notifications(current_user):
    """Get user notifications (placeholder for future implementation)"""
    try:
        # This is a placeholder for notification system
        # In a real implementation, you would have a Notification model
        notifications = []
        
        return jsonify({
            'notifications': notifications,
            'unread_count': 0
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@user_bp.route('/activity', methods=['GET'])
@token_required
def get_user_activity(current_user):
    """Get user activity history (placeholder for future implementation)"""
    try:
        # This is a placeholder for activity tracking
        # In a real implementation, you would have an Activity model
        activities = []
        
        return jsonify({
            'activities': activities
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Public routes (no authentication required)

@user_bp.route('/blog', methods=['GET'])
def get_public_blog_posts():
    """Get published blog posts for public viewing"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        category = request.args.get('category')
        featured = request.args.get('featured', type=bool)
        
        query = BlogPost.query.filter_by(is_published=True)
        
        # Apply filters
        if category:
            query = query.filter(BlogPost.category.ilike(f'%{category}%'))
        
        if featured is not None:
            query = query.filter_by(is_featured=featured)
        
        posts = query.order_by(BlogPost.published_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'posts': [post.to_dict() for post in posts.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': posts.total,
                'pages': posts.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@user_bp.route('/blog/<slug>', methods=['GET'])
def get_blog_post_by_slug(slug):
    """Get a single blog post by slug"""
    try:
        post = BlogPost.query.filter_by(
            slug=slug,
            is_published=True
        ).first()
        
        if not post:
            return jsonify({'error': 'Blog post not found'}), 404
        
        return jsonify({
            'post': post.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@user_bp.route('/blog/categories', methods=['GET'])
def get_blog_categories():
    """Get blog categories"""
    try:
        categories = db.session.query(BlogPost.category)\
            .filter(BlogPost.is_published == True)\
            .distinct().all()
        
        category_list = [category[0] for category in categories if category[0]]
        
        return jsonify({'categories': category_list}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@user_bp.route('/blog/featured', methods=['GET'])
def get_featured_blog_posts():
    """Get featured blog posts"""
    try:
        limit = request.args.get('limit', 5, type=int)
        
        posts = BlogPost.query.filter_by(
            is_published=True,
            is_featured=True
        ).order_by(BlogPost.published_at.desc()).limit(limit).all()
        
        return jsonify({
            'posts': [post.to_dict() for post in posts]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@user_bp.route('/stats', methods=['GET'])
def get_platform_stats():
    """Get public platform statistics"""
    try:
        from src.models.user import Product, Transaction, ProductStatus, TransactionStatus
        
        # Public statistics
        total_products = Product.query.filter_by(
            status=ProductStatus.APPROVED,
            is_active=True
        ).count()
        
        total_vendors = User.query.filter_by(
            role='vendor',
            is_active=True
        ).count()
        
        total_affiliates = User.query.filter_by(
            role='affiliate',
            is_active=True
        ).count()
        
        total_transactions = Transaction.query.filter_by(
            status=TransactionStatus.COMPLETED
        ).count()
        
        return jsonify({
            'statistics': {
                'total_products': total_products,
                'total_vendors': total_vendors,
                'total_affiliates': total_affiliates,
                'total_transactions': total_transactions
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

