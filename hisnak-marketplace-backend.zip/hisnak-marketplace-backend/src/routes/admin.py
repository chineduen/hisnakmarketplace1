from flask import Blueprint, request, jsonify
from src.models.user import (
    db, User, Product, Transaction, Commission, Withdrawal, KYCDocument, 
    BlogPost, ProductReview, UserRole, ProductStatus, TransactionStatus, 
    WithdrawalStatus, KYCStatus
)
from src.routes.auth import token_required, role_required
from datetime import datetime, timezone, timedelta
from decimal import Decimal
import uuid

admin_bp = Blueprint('admin', __name__)

@admin_bp.route('/dashboard', methods=['GET'])
@token_required
@role_required(['admin'])
def get_admin_dashboard(current_user):
    """Get admin dashboard statistics"""
    try:
        # User statistics
        total_users = User.query.count()
        total_vendors = User.query.filter_by(role=UserRole.VENDOR).count()
        total_affiliates = User.query.filter_by(role=UserRole.AFFILIATE).count()
        active_users = User.query.filter_by(is_active=True).count()
        
        # Product statistics
        total_products = Product.query.count()
        pending_products = Product.query.filter_by(status=ProductStatus.PENDING).count()
        approved_products = Product.query.filter_by(status=ProductStatus.APPROVED).count()
        
        # Transaction statistics
        total_transactions = Transaction.query.count()
        completed_transactions = Transaction.query.filter_by(status=TransactionStatus.COMPLETED).count()
        total_revenue = db.session.query(db.func.sum(Transaction.amount)).filter(
            Transaction.status == TransactionStatus.COMPLETED
        ).scalar() or 0
        
        # Commission statistics
        total_commissions = db.session.query(db.func.sum(Commission.amount)).filter(
            Commission.status == 'completed'
        ).scalar() or 0
        
        # Withdrawal statistics
        pending_withdrawals = Withdrawal.query.filter_by(status=WithdrawalStatus.PENDING).count()
        total_withdrawals = db.session.query(db.func.sum(Withdrawal.amount)).filter(
            Withdrawal.status == WithdrawalStatus.COMPLETED
        ).scalar() or 0
        
        # KYC statistics
        pending_kyc = KYCDocument.query.filter_by(status=KYCStatus.PENDING).count()
        
        # Recent activities
        recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
        recent_transactions = Transaction.query.order_by(Transaction.created_at.desc()).limit(5).all()
        recent_products = Product.query.order_by(Product.created_at.desc()).limit(5).all()
        
        return jsonify({
            'statistics': {
                'users': {
                    'total': total_users,
                    'vendors': total_vendors,
                    'affiliates': total_affiliates,
                    'active': active_users
                },
                'products': {
                    'total': total_products,
                    'pending': pending_products,
                    'approved': approved_products
                },
                'transactions': {
                    'total': total_transactions,
                    'completed': completed_transactions,
                    'revenue': float(total_revenue)
                },
                'commissions': {
                    'total_paid': float(total_commissions)
                },
                'withdrawals': {
                    'pending': pending_withdrawals,
                    'total_paid': float(total_withdrawals)
                },
                'kyc': {
                    'pending': pending_kyc
                }
            },
            'recent_activities': {
                'users': [user.to_dict() for user in recent_users],
                'transactions': [transaction.to_dict() for transaction in recent_transactions],
                'products': [product.to_dict() for product in recent_products]
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# User Management

@admin_bp.route('/users', methods=['GET'])
@token_required
@role_required(['admin'])
def get_users(current_user):
    """Get all users with filtering and pagination"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        role = request.args.get('role')
        status = request.args.get('status')
        search = request.args.get('search')
        
        query = User.query
        
        # Apply filters
        if role:
            try:
                role_enum = UserRole(role)
                query = query.filter_by(role=role_enum)
            except ValueError:
                pass
        
        if status == 'active':
            query = query.filter_by(is_active=True)
        elif status == 'inactive':
            query = query.filter_by(is_active=False)
        
        if search:
            query = query.filter(
                db.or_(
                    User.username.ilike(f'%{search}%'),
                    User.email.ilike(f'%{search}%'),
                    User.first_name.ilike(f'%{search}%'),
                    User.last_name.ilike(f'%{search}%')
                )
            )
        
        users = query.order_by(User.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'users': [user.to_dict() for user in users.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': users.total,
                'pages': users.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/users/<user_id>', methods=['GET'])
@token_required
@role_required(['admin'])
def get_user_details(current_user, user_id):
    """Get detailed user information"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        # Get user statistics
        user_data = user.to_dict()
        
        if user.role == UserRole.AFFILIATE:
            # Get affiliate statistics
            total_commissions = db.session.query(db.func.sum(Commission.amount)).filter(
                Commission.affiliate_id == user.id,
                Commission.status == 'completed'
            ).scalar() or 0
            
            total_referrals = User.query.filter_by(referrer_id=user.id).count()
            
            user_data['affiliate_stats'] = {
                'total_earnings': float(total_commissions),
                'total_referrals': total_referrals,
                'balance': user.get_balance()
            }
        
        elif user.role == UserRole.VENDOR:
            # Get vendor statistics
            total_products = Product.query.filter_by(vendor_id=user.id).count()
            approved_products = Product.query.filter_by(
                vendor_id=user.id,
                status=ProductStatus.APPROVED
            ).count()
            
            total_sales = db.session.query(db.func.sum(Transaction.amount)).join(Product).filter(
                Product.vendor_id == user.id,
                Transaction.status == TransactionStatus.COMPLETED
            ).scalar() or 0
            
            user_data['vendor_stats'] = {
                'total_products': total_products,
                'approved_products': approved_products,
                'total_sales': float(total_sales)
            }
        
        return jsonify({'user': user_data}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/users/<user_id>/toggle-status', methods=['POST'])
@token_required
@role_required(['admin'])
def toggle_user_status(current_user, user_id):
    """Activate or deactivate user"""
    try:
        user = User.query.get(user_id)
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        user.is_active = not user.is_active
        user.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        status = 'activated' if user.is_active else 'deactivated'
        return jsonify({
            'message': f'User {status} successfully',
            'user': user.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Product Management

@admin_bp.route('/products', methods=['GET'])
@token_required
@role_required(['admin'])
def get_all_products(current_user):
    """Get all products for admin review"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status')
        category = request.args.get('category')
        search = request.args.get('search')
        
        query = Product.query
        
        # Apply filters
        if status:
            try:
                status_enum = ProductStatus(status)
                query = query.filter_by(status=status_enum)
            except ValueError:
                pass
        
        if category:
            query = query.filter(Product.category.ilike(f'%{category}%'))
        
        if search:
            query = query.filter(
                db.or_(
                    Product.name.ilike(f'%{search}%'),
                    Product.description.ilike(f'%{search}%')
                )
            )
        
        products = query.order_by(Product.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'products': [product.to_dict() for product in products.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': products.total,
                'pages': products.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/products/<product_id>/approve', methods=['POST'])
@token_required
@role_required(['admin'])
def approve_product(current_user, product_id):
    """Approve a product"""
    try:
        product = Product.query.get(product_id)
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        product.status = ProductStatus.APPROVED
        product.approved_at = datetime.now(timezone.utc)
        product.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'message': 'Product approved successfully',
            'product': product.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/products/<product_id>/reject', methods=['POST'])
@token_required
@role_required(['admin'])
def reject_product(current_user, product_id):
    """Reject a product"""
    try:
        product = Product.query.get(product_id)
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        data = request.get_json()
        rejection_reason = data.get('reason', 'Product does not meet platform standards')
        
        product.status = ProductStatus.REJECTED
        product.updated_at = datetime.now(timezone.utc)
        # You might want to add a rejection_reason field to the Product model
        db.session.commit()
        
        return jsonify({
            'message': 'Product rejected successfully',
            'product': product.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/products/<product_id>/feature', methods=['POST'])
@token_required
@role_required(['admin'])
def toggle_product_feature(current_user, product_id):
    """Toggle product featured status"""
    try:
        product = Product.query.get(product_id)
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        product.is_featured = not product.is_featured
        product.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        status = 'featured' if product.is_featured else 'unfeatured'
        return jsonify({
            'message': f'Product {status} successfully',
            'product': product.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# KYC Management

@admin_bp.route('/kyc', methods=['GET'])
@token_required
@role_required(['admin'])
def get_kyc_documents(current_user):
    """Get KYC documents for review"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status')
        
        query = KYCDocument.query
        
        if status:
            try:
                status_enum = KYCStatus(status)
                query = query.filter_by(status=status_enum)
            except ValueError:
                pass
        
        documents = query.order_by(KYCDocument.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'documents': [doc.to_dict() for doc in documents.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': documents.total,
                'pages': documents.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/kyc/<document_id>/approve', methods=['POST'])
@token_required
@role_required(['admin'])
def approve_kyc(current_user, document_id):
    """Approve KYC document"""
    try:
        document = KYCDocument.query.get(document_id)
        if not document:
            return jsonify({'error': 'KYC document not found'}), 404
        
        document.status = KYCStatus.APPROVED
        document.reviewed_at = datetime.now(timezone.utc)
        document.updated_at = datetime.now(timezone.utc)
        
        # Update user verification status
        user = User.query.get(document.user_id)
        if user:
            user.is_verified = True
        
        db.session.commit()
        
        return jsonify({
            'message': 'KYC document approved successfully',
            'document': document.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/kyc/<document_id>/reject', methods=['POST'])
@token_required
@role_required(['admin'])
def reject_kyc(current_user, document_id):
    """Reject KYC document"""
    try:
        document = KYCDocument.query.get(document_id)
        if not document:
            return jsonify({'error': 'KYC document not found'}), 404
        
        data = request.get_json()
        notes = data.get('notes', 'Document does not meet verification requirements')
        
        document.status = KYCStatus.REJECTED
        document.admin_notes = notes
        document.reviewed_at = datetime.now(timezone.utc)
        document.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'message': 'KYC document rejected successfully',
            'document': document.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Withdrawal Management

@admin_bp.route('/withdrawals', methods=['GET'])
@token_required
@role_required(['admin'])
def get_all_withdrawals(current_user):
    """Get all withdrawal requests"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status')
        
        query = Withdrawal.query
        
        if status:
            try:
                status_enum = WithdrawalStatus(status)
                query = query.filter_by(status=status_enum)
            except ValueError:
                pass
        
        withdrawals = query.order_by(Withdrawal.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'withdrawals': [withdrawal.to_dict() for withdrawal in withdrawals.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': withdrawals.total,
                'pages': withdrawals.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/withdrawals/<withdrawal_id>/approve', methods=['POST'])
@token_required
@role_required(['admin'])
def approve_withdrawal(current_user, withdrawal_id):
    """Approve withdrawal request"""
    try:
        withdrawal = Withdrawal.query.get(withdrawal_id)
        if not withdrawal:
            return jsonify({'error': 'Withdrawal request not found'}), 404
        
        # Check user balance
        user = User.query.get(withdrawal.user_id)
        if user.get_balance() < withdrawal.amount:
            return jsonify({'error': 'Insufficient user balance'}), 400
        
        withdrawal.status = WithdrawalStatus.PROCESSING
        withdrawal.processed_at = datetime.now(timezone.utc)
        withdrawal.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        # Here you would integrate with payment gateway to process the withdrawal
        # For now, we'll mark it as completed
        withdrawal.status = WithdrawalStatus.COMPLETED
        db.session.commit()
        
        return jsonify({
            'message': 'Withdrawal approved and processed successfully',
            'withdrawal': withdrawal.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/withdrawals/<withdrawal_id>/reject', methods=['POST'])
@token_required
@role_required(['admin'])
def reject_withdrawal(current_user, withdrawal_id):
    """Reject withdrawal request"""
    try:
        withdrawal = Withdrawal.query.get(withdrawal_id)
        if not withdrawal:
            return jsonify({'error': 'Withdrawal request not found'}), 404
        
        data = request.get_json()
        reason = data.get('reason', 'Withdrawal request does not meet requirements')
        
        withdrawal.status = WithdrawalStatus.CANCELLED
        withdrawal.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'message': 'Withdrawal request rejected successfully',
            'withdrawal': withdrawal.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Blog Management

@admin_bp.route('/blog', methods=['GET'])
@token_required
@role_required(['admin'])
def get_blog_posts(current_user):
    """Get all blog posts"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status')
        
        query = BlogPost.query
        
        if status == 'published':
            query = query.filter_by(is_published=True)
        elif status == 'draft':
            query = query.filter_by(is_published=False)
        
        posts = query.order_by(BlogPost.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'posts': [post.to_dict() for post in posts.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': posts.total,
                'pages': posts.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/blog', methods=['POST'])
@token_required
@role_required(['admin'])
def create_blog_post(current_user):
    """Create a new blog post"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['title', 'content']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} is required'}), 400
        
        # Generate slug from title
        slug = data['title'].lower().replace(' ', '-').replace('/', '-')
        slug = ''.join(c for c in slug if c.isalnum() or c == '-')
        
        # Ensure slug is unique
        existing_post = BlogPost.query.filter_by(slug=slug).first()
        if existing_post:
            slug = f"{slug}-{uuid.uuid4().hex[:8]}"
        
        post = BlogPost(
            author_id=current_user.id,
            title=data['title'],
            slug=slug,
            content=data['content'],
            excerpt=data.get('excerpt'),
            meta_title=data.get('meta_title'),
            meta_description=data.get('meta_description'),
            category=data.get('category'),
            is_published=data.get('is_published', False),
            is_featured=data.get('is_featured', False)
        )
        
        if data.get('tags'):
            post.set_tags_list(data['tags'])
        
        if post.is_published:
            post.published_at = datetime.now(timezone.utc)
        
        db.session.add(post)
        db.session.commit()
        
        return jsonify({
            'message': 'Blog post created successfully',
            'post': post.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/blog/<post_id>', methods=['PUT'])
@token_required
@role_required(['admin'])
def update_blog_post(current_user, post_id):
    """Update blog post"""
    try:
        post = BlogPost.query.get(post_id)
        if not post:
            return jsonify({'error': 'Blog post not found'}), 404
        
        data = request.get_json()
        
        # Update allowed fields
        allowed_fields = [
            'title', 'content', 'excerpt', 'meta_title', 'meta_description',
            'category', 'is_published', 'is_featured'
        ]
        
        for field in allowed_fields:
            if field in data:
                setattr(post, field, data[field])
        
        # Handle tags
        if 'tags' in data:
            post.set_tags_list(data['tags'])
        
        # Update published date if publishing for first time
        if data.get('is_published') and not post.published_at:
            post.published_at = datetime.now(timezone.utc)
        
        post.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'message': 'Blog post updated successfully',
            'post': post.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@admin_bp.route('/blog/<post_id>', methods=['DELETE'])
@token_required
@role_required(['admin'])
def delete_blog_post(current_user, post_id):
    """Delete blog post"""
    try:
        post = BlogPost.query.get(post_id)
        if not post:
            return jsonify({'error': 'Blog post not found'}), 404
        
        db.session.delete(post)
        db.session.commit()
        
        return jsonify({'message': 'Blog post deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

# Analytics and Reports

@admin_bp.route('/analytics/overview', methods=['GET'])
@token_required
@role_required(['admin'])
def get_analytics_overview(current_user):
    """Get platform analytics overview"""
    try:
        # Date range filter
        days = request.args.get('days', 30, type=int)
        start_date = datetime.now(timezone.utc) - timedelta(days=days)
        
        # Revenue analytics
        revenue_data = db.session.query(
            db.func.date(Transaction.completed_at).label('date'),
            db.func.sum(Transaction.amount).label('revenue')
        ).filter(
            Transaction.status == TransactionStatus.COMPLETED,
            Transaction.completed_at >= start_date
        ).group_by(db.func.date(Transaction.completed_at)).all()
        
        # User growth analytics
        user_growth = db.session.query(
            db.func.date(User.created_at).label('date'),
            db.func.count(User.id).label('new_users')
        ).filter(
            User.created_at >= start_date
        ).group_by(db.func.date(User.created_at)).all()
        
        # Top performing products
        top_products = db.session.query(
            Product.name,
            db.func.count(Transaction.id).label('sales_count'),
            db.func.sum(Transaction.amount).label('total_revenue')
        ).join(Transaction).filter(
            Transaction.status == TransactionStatus.COMPLETED,
            Transaction.completed_at >= start_date
        ).group_by(Product.id).order_by(
            db.func.sum(Transaction.amount).desc()
        ).limit(10).all()
        
        # Top affiliates
        top_affiliates = db.session.query(
            User.username,
            User.first_name,
            User.last_name,
            db.func.sum(Commission.amount).label('total_commissions')
        ).join(Commission).filter(
            Commission.status == 'completed',
            Commission.created_at >= start_date
        ).group_by(User.id).order_by(
            db.func.sum(Commission.amount).desc()
        ).limit(10).all()
        
        return jsonify({
            'revenue_data': [
                {'date': str(item.date), 'revenue': float(item.revenue)}
                for item in revenue_data
            ],
            'user_growth': [
                {'date': str(item.date), 'new_users': item.new_users}
                for item in user_growth
            ],
            'top_products': [
                {
                    'name': item.name,
                    'sales_count': item.sales_count,
                    'total_revenue': float(item.total_revenue)
                }
                for item in top_products
            ],
            'top_affiliates': [
                {
                    'username': item.username,
                    'name': f"{item.first_name} {item.last_name}",
                    'total_commissions': float(item.total_commissions)
                }
                for item in top_affiliates
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

