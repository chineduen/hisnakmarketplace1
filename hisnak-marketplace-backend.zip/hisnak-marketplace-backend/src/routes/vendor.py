from flask import Blueprint, request, jsonify
from src.models.user import (
    db, User, Product, Transaction, AffiliateLink, ProductReview,
    ProductStatus, TransactionStatus, UserRole
)
from src.routes.auth import token_required, role_required
from datetime import datetime, timezone, timedelta
from decimal import Decimal
import uuid

vendor_bp = Blueprint('vendor', __name__)

@vendor_bp.route('/dashboard', methods=['GET'])
@token_required
@role_required(['vendor'])
def get_vendor_dashboard(current_user):
    """Get vendor dashboard statistics"""
    try:
        # Product statistics
        total_products = Product.query.filter_by(vendor_id=current_user.id).count()
        approved_products = Product.query.filter_by(
            vendor_id=current_user.id,
            status=ProductStatus.APPROVED
        ).count()
        pending_products = Product.query.filter_by(
            vendor_id=current_user.id,
            status=ProductStatus.PENDING
        ).count()
        
        # Sales statistics
        total_sales = db.session.query(db.func.count(Transaction.id)).join(Product).filter(
            Product.vendor_id == current_user.id,
            Transaction.status == TransactionStatus.COMPLETED
        ).scalar() or 0
        
        total_revenue = db.session.query(db.func.sum(Transaction.amount)).join(Product).filter(
            Product.vendor_id == current_user.id,
            Transaction.status == TransactionStatus.COMPLETED
        ).scalar() or 0
        
        # Affiliate statistics
        total_affiliates = db.session.query(db.func.count(db.distinct(AffiliateLink.affiliate_id))).join(Product).filter(
            Product.vendor_id == current_user.id,
            AffiliateLink.is_active == True
        ).scalar() or 0
        
        # Recent transactions
        recent_transactions = db.session.query(Transaction).join(Product).filter(
            Product.vendor_id == current_user.id
        ).order_by(Transaction.created_at.desc()).limit(5).all()
        
        # Top performing products
        top_products = db.session.query(
            Product.name,
            db.func.count(Transaction.id).label('sales_count'),
            db.func.sum(Transaction.amount).label('revenue')
        ).outerjoin(Transaction).filter(
            Product.vendor_id == current_user.id,
            Transaction.status == TransactionStatus.COMPLETED
        ).group_by(Product.id).order_by(
            db.func.sum(Transaction.amount).desc()
        ).limit(5).all()
        
        return jsonify({
            'statistics': {
                'products': {
                    'total': total_products,
                    'approved': approved_products,
                    'pending': pending_products
                },
                'sales': {
                    'total_orders': total_sales,
                    'total_revenue': float(total_revenue)
                },
                'affiliates': {
                    'total_active': total_affiliates
                }
            },
            'recent_transactions': [transaction.to_dict() for transaction in recent_transactions],
            'top_products': [
                {
                    'name': product.name,
                    'sales_count': product.sales_count or 0,
                    'revenue': float(product.revenue or 0)
                }
                for product in top_products
            ]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@vendor_bp.route('/products', methods=['GET'])
@token_required
@role_required(['vendor'])
def get_vendor_products(current_user):
    """Get vendor's products"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status')
        search = request.args.get('search')
        
        query = Product.query.filter_by(vendor_id=current_user.id)
        
        # Apply filters
        if status:
            try:
                status_enum = ProductStatus(status)
                query = query.filter_by(status=status_enum)
            except ValueError:
                pass
        
        if search:
            query = query.filter(
                db.or_(
                    Product.name.ilike(f'%{search}%'),
                    Product.description.ilike(f'%{search}%')
                )
            )
        
        products = query.order_by(Product.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'products': [product.to_dict() for product in products.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': products.total,
                'pages': products.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@vendor_bp.route('/products/<product_id>/analytics', methods=['GET'])
@token_required
@role_required(['vendor'])
def get_product_analytics(current_user, product_id):
    """Get detailed analytics for a specific product"""
    try:
        # Verify product ownership
        product = Product.query.filter_by(
            id=product_id,
            vendor_id=current_user.id
        ).first()
        
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # Date range filter
        days = request.args.get('days', 30, type=int)
        start_date = datetime.now(timezone.utc) - timedelta(days=days)
        
        # Sales analytics
        sales_data = db.session.query(
            db.func.date(Transaction.completed_at).label('date'),
            db.func.count(Transaction.id).label('sales'),
            db.func.sum(Transaction.amount).label('revenue')
        ).filter(
            Transaction.product_id == product_id,
            Transaction.status == TransactionStatus.COMPLETED,
            Transaction.completed_at >= start_date
        ).group_by(db.func.date(Transaction.completed_at)).all()
        
        # Affiliate performance
        affiliate_performance = db.session.query(
            User.username,
            User.first_name,
            User.last_name,
            AffiliateLink.clicks_count,
            AffiliateLink.conversions_count,
            db.func.sum(Transaction.amount).label('revenue_generated')
        ).join(AffiliateLink, User.id == AffiliateLink.affiliate_id)\
        .outerjoin(Transaction, AffiliateLink.id == Transaction.affiliate_link_id)\
        .filter(
            AffiliateLink.product_id == product_id,
            AffiliateLink.is_active == True
        ).group_by(User.id, AffiliateLink.id).all()
        
        # Traffic sources
        traffic_sources = db.session.query(
            Transaction.payment_method.label('source'),
            db.func.count(Transaction.id).label('count')
        ).filter(
            Transaction.product_id == product_id,
            Transaction.status == TransactionStatus.COMPLETED,
            Transaction.completed_at >= start_date
        ).group_by(Transaction.payment_method).all()
        
        # Reviews summary
        reviews_summary = db.session.query(
            db.func.avg(ProductReview.rating).label('average_rating'),
            db.func.count(ProductReview.id).label('total_reviews')
        ).filter(
            ProductReview.product_id == product_id,
            ProductReview.is_approved == True
        ).first()
        
        return jsonify({
            'product': product.to_dict(),
            'sales_data': [
                {
                    'date': str(item.date),
                    'sales': item.sales,
                    'revenue': float(item.revenue)
                }
                for item in sales_data
            ],
            'affiliate_performance': [
                {
                    'affiliate': {
                        'username': item.username,
                        'name': f"{item.first_name} {item.last_name}"
                    },
                    'clicks': item.clicks_count,
                    'conversions': item.conversions_count,
                    'conversion_rate': (item.conversions_count / item.clicks_count * 100) if item.clicks_count > 0 else 0,
                    'revenue_generated': float(item.revenue_generated or 0)
                }
                for item in affiliate_performance
            ],
            'traffic_sources': [
                {
                    'source': item.source,
                    'count': item.count
                }
                for item in traffic_sources
            ],
            'reviews_summary': {
                'average_rating': float(reviews_summary.average_rating or 0),
                'total_reviews': reviews_summary.total_reviews or 0
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@vendor_bp.route('/orders', methods=['GET'])
@token_required
@role_required(['vendor'])
def get_vendor_orders(current_user):
    """Get vendor's orders/transactions"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        status = request.args.get('status')
        
        query = db.session.query(Transaction).join(Product).filter(
            Product.vendor_id == current_user.id
        )
        
        # Apply status filter
        if status:
            try:
                status_enum = TransactionStatus(status)
                query = query.filter(Transaction.status == status_enum)
            except ValueError:
                pass
        
        orders = query.order_by(Transaction.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        # Enhance orders with product information
        orders_data = []
        for order in orders.items:
            order_dict = order.to_dict()
            order_dict['product'] = order.product.to_dict()
            orders_data.append(order_dict)
        
        return jsonify({
            'orders': orders_data,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': orders.total,
                'pages': orders.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@vendor_bp.route('/affiliates', methods=['GET'])
@token_required
@role_required(['vendor'])
def get_vendor_affiliates(current_user):
    """Get affiliates promoting vendor's products"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        # Get affiliates with their performance data
        affiliates_query = db.session.query(
            User.id,
            User.username,
            User.first_name,
            User.last_name,
            User.email,
            db.func.count(AffiliateLink.id).label('active_links'),
            db.func.sum(AffiliateLink.clicks_count).label('total_clicks'),
            db.func.sum(AffiliateLink.conversions_count).label('total_conversions'),
            db.func.sum(Transaction.amount).label('revenue_generated')
        ).join(AffiliateLink, User.id == AffiliateLink.affiliate_id)\
        .join(Product, AffiliateLink.product_id == Product.id)\
        .outerjoin(Transaction, AffiliateLink.id == Transaction.affiliate_link_id)\
        .filter(
            Product.vendor_id == current_user.id,
            AffiliateLink.is_active == True
        ).group_by(User.id)
        
        affiliates = affiliates_query.paginate(page=page, per_page=per_page, error_out=False)
        
        affiliates_data = []
        for affiliate in affiliates.items:
            affiliate_data = {
                'id': affiliate.id,
                'username': affiliate.username,
                'name': f"{affiliate.first_name} {affiliate.last_name}",
                'email': affiliate.email,
                'performance': {
                    'active_links': affiliate.active_links or 0,
                    'total_clicks': affiliate.total_clicks or 0,
                    'total_conversions': affiliate.total_conversions or 0,
                    'conversion_rate': (affiliate.total_conversions / affiliate.total_clicks * 100) if affiliate.total_clicks and affiliate.total_clicks > 0 else 0,
                    'revenue_generated': float(affiliate.revenue_generated or 0)
                }
            }
            affiliates_data.append(affiliate_data)
        
        return jsonify({
            'affiliates': affiliates_data,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': affiliates.total,
                'pages': affiliates.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@vendor_bp.route('/products/<product_id>/affiliates', methods=['GET'])
@token_required
@role_required(['vendor'])
def get_product_affiliates(current_user, product_id):
    """Get affiliates for a specific product"""
    try:
        # Verify product ownership
        product = Product.query.filter_by(
            id=product_id,
            vendor_id=current_user.id
        ).first()
        
        if not product:
            return jsonify({'error': 'Product not found'}), 404
        
        # Get affiliate links for this product
        affiliate_links = db.session.query(
            AffiliateLink,
            User.username,
            User.first_name,
            User.last_name,
            User.email
        ).join(User, AffiliateLink.affiliate_id == User.id)\
        .filter(
            AffiliateLink.product_id == product_id,
            AffiliateLink.is_active == True
        ).all()
        
        affiliates_data = []
        for link, username, first_name, last_name, email in affiliate_links:
            link_data = link.to_dict()
            link_data['affiliate'] = {
                'username': username,
                'name': f"{first_name} {last_name}",
                'email': email
            }
            affiliates_data.append(link_data)
        
        return jsonify({
            'product': product.to_dict(),
            'affiliate_links': affiliates_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@vendor_bp.route('/analytics/overview', methods=['GET'])
@token_required
@role_required(['vendor'])
def get_vendor_analytics(current_user):
    """Get comprehensive vendor analytics"""
    try:
        # Date range filter
        days = request.args.get('days', 30, type=int)
        start_date = datetime.now(timezone.utc) - timedelta(days=days)
        
        # Revenue over time
        revenue_data = db.session.query(
            db.func.date(Transaction.completed_at).label('date'),
            db.func.sum(Transaction.amount).label('revenue'),
            db.func.count(Transaction.id).label('orders')
        ).join(Product).filter(
            Product.vendor_id == current_user.id,
            Transaction.status == TransactionStatus.COMPLETED,
            Transaction.completed_at >= start_date
        ).group_by(db.func.date(Transaction.completed_at)).all()
        
        # Product performance
        product_performance = db.session.query(
            Product.name,
            Product.views_count,
            db.func.count(Transaction.id).label('sales'),
            db.func.sum(Transaction.amount).label('revenue'),
            db.func.avg(ProductReview.rating).label('avg_rating')
        ).outerjoin(Transaction, Product.id == Transaction.product_id)\
        .outerjoin(ProductReview, Product.id == ProductReview.product_id)\
        .filter(
            Product.vendor_id == current_user.id,
            db.or_(Transaction.status == TransactionStatus.COMPLETED, Transaction.id.is_(None))
        ).group_by(Product.id).all()
        
        # Affiliate channel performance
        affiliate_channels = db.session.query(
            db.func.count(Transaction.id).label('sales'),
            db.func.sum(Transaction.amount).label('revenue')
        ).join(Product).outerjoin(AffiliateLink, Transaction.affiliate_link_id == AffiliateLink.id)\
        .filter(
            Product.vendor_id == current_user.id,
            Transaction.status == TransactionStatus.COMPLETED,
            Transaction.completed_at >= start_date
        ).first()
        
        # Direct sales (no affiliate)
        direct_sales = db.session.query(
            db.func.count(Transaction.id).label('sales'),
            db.func.sum(Transaction.amount).label('revenue')
        ).join(Product).filter(
            Product.vendor_id == current_user.id,
            Transaction.status == TransactionStatus.COMPLETED,
            Transaction.affiliate_link_id.is_(None),
            Transaction.completed_at >= start_date
        ).first()
        
        return jsonify({
            'revenue_data': [
                {
                    'date': str(item.date),
                    'revenue': float(item.revenue),
                    'orders': item.orders
                }
                for item in revenue_data
            ],
            'product_performance': [
                {
                    'name': item.name,
                    'views': item.views_count,
                    'sales': item.sales or 0,
                    'revenue': float(item.revenue or 0),
                    'average_rating': float(item.avg_rating or 0),
                    'conversion_rate': (item.sales / item.views_count * 100) if item.views_count > 0 else 0
                }
                for item in product_performance
            ],
            'sales_channels': {
                'affiliate': {
                    'sales': affiliate_channels.sales or 0,
                    'revenue': float(affiliate_channels.revenue or 0)
                },
                'direct': {
                    'sales': direct_sales.sales or 0,
                    'revenue': float(direct_sales.revenue or 0)
                }
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@vendor_bp.route('/reviews', methods=['GET'])
@token_required
@role_required(['vendor'])
def get_vendor_reviews(current_user):
    """Get reviews for vendor's products"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        product_id = request.args.get('product_id')
        rating = request.args.get('rating', type=int)
        
        query = db.session.query(ProductReview).join(Product).filter(
            Product.vendor_id == current_user.id
        )
        
        # Apply filters
        if product_id:
            query = query.filter(ProductReview.product_id == product_id)
        
        if rating:
            query = query.filter(ProductReview.rating == rating)
        
        reviews = query.order_by(ProductReview.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        # Enhance reviews with product information
        reviews_data = []
        for review in reviews.items:
            review_dict = review.to_dict()
            review_dict['product'] = {
                'id': review.product.id,
                'name': review.product.name
            }
            reviews_data.append(review_dict)
        
        return jsonify({
            'reviews': reviews_data,
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': reviews.total,
                'pages': reviews.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@vendor_bp.route('/profile', methods=['GET'])
@token_required
@role_required(['vendor'])
def get_vendor_profile(current_user):
    """Get vendor profile with business information"""
    try:
        # Get vendor statistics
        vendor_stats = {
            'total_products': Product.query.filter_by(vendor_id=current_user.id).count(),
            'approved_products': Product.query.filter_by(
                vendor_id=current_user.id,
                status=ProductStatus.APPROVED
            ).count(),
            'total_sales': db.session.query(db.func.count(Transaction.id)).join(Product).filter(
                Product.vendor_id == current_user.id,
                Transaction.status == TransactionStatus.COMPLETED
            ).scalar() or 0,
            'total_revenue': db.session.query(db.func.sum(Transaction.amount)).join(Product).filter(
                Product.vendor_id == current_user.id,
                Transaction.status == TransactionStatus.COMPLETED
            ).scalar() or 0,
            'average_rating': db.session.query(db.func.avg(ProductReview.rating)).join(Product).filter(
                Product.vendor_id == current_user.id,
                ProductReview.is_approved == True
            ).scalar() or 0
        }
        
        profile_data = current_user.to_dict()
        profile_data['vendor_stats'] = {
            'total_products': vendor_stats['total_products'],
            'approved_products': vendor_stats['approved_products'],
            'total_sales': vendor_stats['total_sales'],
            'total_revenue': float(vendor_stats['total_revenue']),
            'average_rating': float(vendor_stats['average_rating'])
        }
        
        return jsonify({'profile': profile_data}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

