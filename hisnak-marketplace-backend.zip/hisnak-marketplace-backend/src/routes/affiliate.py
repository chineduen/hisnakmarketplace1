from flask import Blueprint, request, jsonify, current_app
from src.models.user import db, User, Product, AffiliateLink, Commission, Transaction, LinkClick
from src.routes.auth import token_required, role_required
from datetime import datetime, timezone
from decimal import Decimal
import uuid
import logging

affiliate_bp = Blueprint('affiliate', __name__)
logger = logging.getLogger(__name__)

def calculate_commissions(transaction, affiliate_link):
    """
    Calculate and create commission records for multi-level affiliate system
    Level 1 (Direct): 50% commission to the affiliate who made the sale
    Level 2 (Indirect): 10% commission to the recruiter (who referred the affiliate)
    Platform: 40% goes to Hisnak Marketplace
    """
    try:
        commissions = []
        product = transaction.product
        affiliate = User.query.get(affiliate_link.affiliate_id)
        
        if not affiliate:
            logger.error(f"Affiliate not found for link {affiliate_link.id}")
            return commissions
        
        # Calculate commission amounts
        total_amount = transaction.amount
        commission_rate = product.commission_percentage / 100  # Convert percentage to decimal
        
        # Level 1 Commission (Direct Affiliate) - 50%
        level1_percentage = Decimal('50.00')
        level1_amount = (total_amount * commission_rate * level1_percentage) / 100
        
        level1_commission = Commission(
            transaction_id=transaction.id,
            affiliate_id=affiliate.id,
            commission_type='direct',
            commission_level=1,
            amount=level1_amount,
            percentage=level1_percentage,
            status='completed'
        )
        commissions.append(level1_commission)
        
        # Level 2 Commission (Indirect - Recruiter) - 10%
        if affiliate.referrer_id:
            recruiter = User.query.get(affiliate.referrer_id)
            if recruiter:
                level2_percentage = Decimal('10.00')
                level2_amount = (total_amount * commission_rate * level2_percentage) / 100
                
                level2_commission = Commission(
                    transaction_id=transaction.id,
                    affiliate_id=recruiter.id,
                    commission_type='indirect',
                    commission_level=2,
                    amount=level2_amount,
                    percentage=level2_percentage,
                    status='completed'
                )
                commissions.append(level2_commission)
        
        # Save all commissions
        for commission in commissions:
            db.session.add(commission)
        
        db.session.commit()
        logger.info(f"Created {len(commissions)} commission records for transaction {transaction.id}")
        
        return commissions
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error calculating commissions: {str(e)}")
        return []

@affiliate_bp.route('/dashboard', methods=['GET'])
@token_required
@role_required(['affiliate'])
def get_dashboard(current_user):
    """Get affiliate dashboard data"""
    try:
        # Get affiliate statistics
        total_commissions = db.session.query(db.func.sum(Commission.amount)).filter(
            Commission.affiliate_id == current_user.id,
            Commission.status == 'completed'
        ).scalar() or 0
        
        # Get commission breakdown by level
        level1_commissions = db.session.query(db.func.sum(Commission.amount)).filter(
            Commission.affiliate_id == current_user.id,
            Commission.commission_level == 1,
            Commission.status == 'completed'
        ).scalar() or 0
        
        level2_commissions = db.session.query(db.func.sum(Commission.amount)).filter(
            Commission.affiliate_id == current_user.id,
            Commission.commission_level == 2,
            Commission.status == 'completed'
        ).scalar() or 0
        
        # Get affiliate links count
        active_links = AffiliateLink.query.filter(
            AffiliateLink.affiliate_id == current_user.id,
            AffiliateLink.is_active == True
        ).count()
        
        # Get total clicks and conversions
        total_clicks = db.session.query(db.func.sum(AffiliateLink.clicks_count)).filter(
            AffiliateLink.affiliate_id == current_user.id
        ).scalar() or 0
        
        total_conversions = db.session.query(db.func.sum(AffiliateLink.conversions_count)).filter(
            AffiliateLink.affiliate_id == current_user.id
        ).scalar() or 0
        
        # Get referral statistics
        direct_referrals = User.query.filter_by(referrer_id=current_user.id).count()
        
        # Get recent commissions
        recent_commissions = Commission.query.filter_by(affiliate_id=current_user.id)\
            .order_by(Commission.created_at.desc()).limit(10).all()
        
        # Get referral tree
        referral_tree = current_user.get_referral_tree()
        
        return jsonify({
            'statistics': {
                'total_earnings': float(total_commissions),
                'level1_earnings': float(level1_commissions),
                'level2_earnings': float(level2_commissions),
                'current_balance': current_user.get_balance(),
                'active_links': active_links,
                'total_clicks': total_clicks,
                'total_conversions': total_conversions,
                'conversion_rate': (total_conversions / total_clicks * 100) if total_clicks > 0 else 0,
                'direct_referrals': direct_referrals
            },
            'recent_commissions': [commission.to_dict() for commission in recent_commissions],
            'referral_tree': referral_tree,
            'user': current_user.to_dict()
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@affiliate_bp.route('/links', methods=['GET'])
@token_required
@role_required(['affiliate'])
def get_affiliate_links(current_user):
    """Get all affiliate links for current user"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        links = AffiliateLink.query.filter_by(affiliate_id=current_user.id)\
            .order_by(AffiliateLink.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'links': [link.to_dict() for link in links.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': links.total,
                'pages': links.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@affiliate_bp.route('/links', methods=['POST'])
@token_required
@role_required(['affiliate'])
def create_affiliate_link(current_user):
    """Create a new affiliate link for a product"""
    try:
        data = request.get_json()
        
        if not data.get('product_id'):
            return jsonify({'error': 'Product ID is required'}), 400
        
        # Check if product exists and is approved
        product = Product.query.filter_by(
            id=data['product_id'],
            status='approved',
            is_active=True
        ).first()
        
        if not product:
            return jsonify({'error': 'Product not found or not available'}), 404
        
        # Check if affiliate already has a link for this product
        existing_link = AffiliateLink.query.filter_by(
            affiliate_id=current_user.id,
            product_id=product.id
        ).first()
        
        if existing_link:
            return jsonify({'error': 'Affiliate link already exists for this product'}), 400
        
        # Create new affiliate link
        affiliate_link = AffiliateLink(
            affiliate_id=current_user.id,
            product_id=product.id,
            custom_url=data.get('custom_url')
        )
        
        affiliate_link.generate_link_code()
        
        db.session.add(affiliate_link)
        db.session.commit()
        
        return jsonify({
            'message': 'Affiliate link created successfully',
            'link': affiliate_link.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@affiliate_bp.route('/links/<link_id>', methods=['PUT'])
@token_required
@role_required(['affiliate'])
def update_affiliate_link(current_user, link_id):
    """Update an affiliate link"""
    try:
        link = AffiliateLink.query.filter_by(
            id=link_id,
            affiliate_id=current_user.id
        ).first()
        
        if not link:
            return jsonify({'error': 'Affiliate link not found'}), 404
        
        data = request.get_json()
        
        # Update allowed fields
        if 'custom_url' in data:
            link.custom_url = data['custom_url']
        
        if 'is_active' in data:
            link.is_active = data['is_active']
        
        link.updated_at = datetime.now(timezone.utc)
        db.session.commit()
        
        return jsonify({
            'message': 'Affiliate link updated successfully',
            'link': link.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@affiliate_bp.route('/links/<link_id>', methods=['DELETE'])
@token_required
@role_required(['affiliate'])
def delete_affiliate_link(current_user, link_id):
    """Delete an affiliate link"""
    try:
        link = AffiliateLink.query.filter_by(
            id=link_id,
            affiliate_id=current_user.id
        ).first()
        
        if not link:
            return jsonify({'error': 'Affiliate link not found'}), 404
        
        db.session.delete(link)
        db.session.commit()
        
        return jsonify({'message': 'Affiliate link deleted successfully'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@affiliate_bp.route('/commissions', methods=['GET'])
@token_required
@role_required(['affiliate'])
def get_commissions(current_user):
    """Get commission history for current user"""
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        commission_type = request.args.get('type')  # 'direct' or 'indirect'
        
        query = Commission.query.filter_by(affiliate_id=current_user.id)
        
        if commission_type:
            query = query.filter_by(commission_type=commission_type)
        
        commissions = query.order_by(Commission.created_at.desc())\
            .paginate(page=page, per_page=per_page, error_out=False)
        
        return jsonify({
            'commissions': [commission.to_dict() for commission in commissions.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': commissions.total,
                'pages': commissions.pages
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@affiliate_bp.route('/referrals', methods=['GET'])
@token_required
@role_required(['affiliate'])
def get_referrals(current_user):
    """Get referral information and tree"""
    try:
        # Get direct referrals
        direct_referrals = User.query.filter_by(referrer_id=current_user.id).all()
        
        # Get referral tree (2 levels)
        referral_tree = current_user.get_referral_tree()
        
        # Calculate referral statistics
        total_referrals = len(direct_referrals)
        active_referrals = len([r for r in direct_referrals if r.is_active])
        
        # Get commissions from referrals
        referral_commissions = Commission.query.filter_by(
            affiliate_id=current_user.id,
            commission_type='indirect'
        ).all()
        
        total_referral_earnings = sum(c.amount for c in referral_commissions)
        
        return jsonify({
            'statistics': {
                'total_referrals': total_referrals,
                'active_referrals': active_referrals,
                'total_referral_earnings': float(total_referral_earnings)
            },
            'direct_referrals': [user.to_dict() for user in direct_referrals],
            'referral_tree': referral_tree,
            'referral_code': current_user.referral_code,
            'referral_link': f"{request.host_url}register?ref={current_user.referral_code}"
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@affiliate_bp.route('/track-click/<link_code>', methods=['POST'])
def track_click(link_code):
    """Track affiliate link click"""
    try:
        # Find affiliate link
        affiliate_link = AffiliateLink.query.filter_by(
            link_code=link_code,
            is_active=True
        ).first()
        
        if not affiliate_link:
            return jsonify({'error': 'Invalid affiliate link'}), 404
        
        # Get request information
        ip_address = request.environ.get('HTTP_X_FORWARDED_FOR', request.environ.get('REMOTE_ADDR'))
        user_agent = request.headers.get('User-Agent')
        referrer = request.headers.get('Referer')
        
        # Create click record
        click = LinkClick(
            affiliate_link_id=affiliate_link.id,
            ip_address=ip_address,
            user_agent=user_agent,
            referrer=referrer
        )
        
        # Update affiliate link click count
        affiliate_link.clicks_count += 1
        
        db.session.add(click)
        db.session.commit()
        
        # Return product information for redirect
        product = affiliate_link.product
        
        return jsonify({
            'message': 'Click tracked successfully',
            'product': product.to_dict(),
            'redirect_url': f"/products/{product.id}"
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@affiliate_bp.route('/performance', methods=['GET'])
@token_required
@role_required(['affiliate'])
def get_performance_analytics(current_user):
    """Get detailed performance analytics for affiliate"""
    try:
        # Date range filter
        from_date = request.args.get('from_date')
        to_date = request.args.get('to_date')
        
        # Base queries
        commissions_query = Commission.query.filter_by(affiliate_id=current_user.id)
        links_query = AffiliateLink.query.filter_by(affiliate_id=current_user.id)
        
        # Apply date filters if provided
        if from_date:
            from_date = datetime.fromisoformat(from_date)
            commissions_query = commissions_query.filter(Commission.created_at >= from_date)
            links_query = links_query.filter(AffiliateLink.created_at >= from_date)
        
        if to_date:
            to_date = datetime.fromisoformat(to_date)
            commissions_query = commissions_query.filter(Commission.created_at <= to_date)
            links_query = links_query.filter(AffiliateLink.created_at <= to_date)
        
        # Get performance data
        commissions = commissions_query.all()
        links = links_query.all()
        
        # Calculate metrics
        total_earnings = sum(c.amount for c in commissions)
        direct_earnings = sum(c.amount for c in commissions if c.commission_type == 'direct')
        indirect_earnings = sum(c.amount for c in commissions if c.commission_type == 'indirect')
        
        total_clicks = sum(l.clicks_count for l in links)
        total_conversions = sum(l.conversions_count for l in links)
        
        # Top performing products
        product_performance = {}
        for link in links:
            if link.product_id not in product_performance:
                product_performance[link.product_id] = {
                    'product': link.product.to_dict(),
                    'clicks': 0,
                    'conversions': 0,
                    'earnings': 0
                }
            
            product_performance[link.product_id]['clicks'] += link.clicks_count
            product_performance[link.product_id]['conversions'] += link.conversions_count
            
            # Calculate earnings for this product
            product_commissions = [c for c in commissions if c.transaction.product_id == link.product_id]
            product_performance[link.product_id]['earnings'] += sum(c.amount for c in product_commissions)
        
        top_products = sorted(
            product_performance.values(),
            key=lambda x: x['earnings'],
            reverse=True
        )[:5]
        
        return jsonify({
            'summary': {
                'total_earnings': float(total_earnings),
                'direct_earnings': float(direct_earnings),
                'indirect_earnings': float(indirect_earnings),
                'total_clicks': total_clicks,
                'total_conversions': total_conversions,
                'conversion_rate': (total_conversions / total_clicks * 100) if total_clicks > 0 else 0
            },
            'top_products': top_products,
            'commission_breakdown': {
                'direct': len([c for c in commissions if c.commission_type == 'direct']),
                'indirect': len([c for c in commissions if c.commission_type == 'indirect'])
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

